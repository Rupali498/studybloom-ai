import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { 
  Layers, 
  ChevronLeft, 
  ChevronRight, 
  RotateCcw,
  Trash2,
  Loader2,
  Brain
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface Flashcard {
  id: string;
  front: string;
  back: string;
}

interface Deck {
  id: string;
  title: string;
  description: string | null;
  created_at: string;
  flashcards?: Flashcard[];
}

export default function Flashcards() {
  const { toast } = useToast();
  const [decks, setDecks] = useState<Deck[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDeck, setSelectedDeck] = useState<Deck | null>(null);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  useEffect(() => {
    fetchDecks();
  }, []);

  const fetchDecks = async () => {
    const { data, error } = await supabase
      .from('flashcard_decks')
      .select(`
        *,
        flashcards (*)
      `)
      .order('created_at', { ascending: false });

    if (error) {
      toast({ title: 'Error', description: 'Failed to load flashcards', variant: 'destructive' });
    } else {
      setDecks(data || []);
    }
    setLoading(false);
  };

  const handleDeleteDeck = async (id: string) => {
    const { error } = await supabase.from('flashcard_decks').delete().eq('id', id);

    if (error) {
      toast({ title: 'Error', description: 'Failed to delete deck', variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: 'Deck deleted' });
      fetchDecks();
      if (selectedDeck?.id === id) {
        setSelectedDeck(null);
      }
    }
  };

  const nextCard = () => {
    if (selectedDeck?.flashcards) {
      setIsFlipped(false);
      setCurrentCardIndex((prev) => 
        prev < selectedDeck.flashcards!.length - 1 ? prev + 1 : 0
      );
    }
  };

  const prevCard = () => {
    if (selectedDeck?.flashcards) {
      setIsFlipped(false);
      setCurrentCardIndex((prev) => 
        prev > 0 ? prev - 1 : selectedDeck.flashcards!.length - 1
      );
    }
  };

  const resetDeck = () => {
    setCurrentCardIndex(0);
    setIsFlipped(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  // Show deck study view
  if (selectedDeck && selectedDeck.flashcards && selectedDeck.flashcards.length > 0) {
    const currentCard = selectedDeck.flashcards[currentCardIndex];

    return (
      <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={() => { setSelectedDeck(null); resetDeck(); }}>
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back to Decks
          </Button>
          <span className="text-sm text-muted-foreground">
            {currentCardIndex + 1} / {selectedDeck.flashcards.length}
          </span>
        </div>

        <h2 className="text-xl font-semibold text-foreground text-center">
          {selectedDeck.title}
        </h2>

        {/* Flashcard */}
        <div
          className={`flip-card cursor-pointer ${isFlipped ? 'flipped' : ''}`}
          onClick={() => setIsFlipped(!isFlipped)}
          style={{ height: '300px' }}
        >
          <div className="flip-card-inner relative w-full h-full">
            {/* Front */}
            <div className="flip-card-front absolute inset-0 glass-card rounded-2xl p-8 flex flex-col items-center justify-center text-center">
              <span className="text-xs text-muted-foreground mb-4 uppercase tracking-wide">Question</span>
              <p className="text-xl font-medium text-foreground">{currentCard.front}</p>
              <span className="text-xs text-muted-foreground mt-6">Tap to reveal answer</span>
            </div>
            
            {/* Back */}
            <div className="flip-card-back absolute inset-0 glass-card rounded-2xl p-8 flex flex-col items-center justify-center text-center bg-primary/5">
              <span className="text-xs text-primary mb-4 uppercase tracking-wide">Answer</span>
              <p className="text-xl font-medium text-foreground">{currentCard.back}</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-center gap-4">
          <Button variant="outline" size="icon" onClick={prevCard}>
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <Button variant="outline" size="icon" onClick={resetDeck}>
            <RotateCcw className="w-5 h-5" />
          </Button>
          <Button variant="outline" size="icon" onClick={nextCard}>
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>

        {/* Quiz Link */}
        <div className="text-center pt-4">
          <Link to={`/quiz?deck=${selectedDeck.id}`}>
            <Button variant="default" className="gap-2">
              <Brain className="w-4 h-4" />
              Take Quiz on This Deck
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Flashcards</h1>
        <p className="text-muted-foreground">Review your AI-generated flashcard decks</p>
      </div>

      {decks.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center">
          <Layers className="w-16 h-16 text-muted-foreground/50 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No flashcard decks yet</h3>
          <p className="text-muted-foreground mb-6">
            Generate flashcards from your notes to start studying
          </p>
          <Link to="/notes">
            <Button>Go to Notes</Button>
          </Link>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {decks.map((deck) => (
            <div
              key={deck.id}
              className="glass-card rounded-xl p-5 card-hover group"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center">
                  <Layers className="w-5 h-5 text-secondary" />
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => handleDeleteDeck(deck.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>

              <h3 className="font-semibold text-foreground mb-1 line-clamp-1">
                {deck.title}
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                {deck.flashcards?.length || 0} cards
              </p>

              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => setSelectedDeck(deck)}
                disabled={!deck.flashcards || deck.flashcards.length === 0}
              >
                Study Deck
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
