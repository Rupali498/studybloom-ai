import { useAuth } from '@/hooks/useAuth';
import { AuthForm } from '@/components/AuthForm';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  Leaf, 
  BookOpen, 
  Layers, 
  Brain, 
  Sparkles,
  ArrowRight 
} from 'lucide-react';

export default function Index() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse">
          <Leaf className="w-12 h-12 text-primary" />
        </div>
      </div>
    );
  }

  // Show landing + auth for non-authenticated users
  if (!user) {
    return (
      <div className="min-h-screen bg-background" style={{ background: 'var(--gradient-hero)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Header */}
          <header className="flex items-center justify-between mb-20">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
                <Leaf className="w-7 h-7 text-primary" />
              </div>
              <span className="font-semibold text-xl text-foreground">StudySpring</span>
            </div>
          </header>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Hero Section */}
            <div className="space-y-8 animate-slide-in">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium">
                <Sparkles className="w-4 h-4" />
                AI-Powered Learning
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight">
                Study Smarter,
                <br />
                <span className="gradient-text">Not Harder</span>
              </h1>
              
              <p className="text-lg text-muted-foreground max-w-lg">
                Transform your notes into flashcards and quizzes with AI. 
                The intelligent study assistant that adapts to how you learn.
              </p>

              {/* Feature Cards */}
              <div className="grid sm:grid-cols-3 gap-4 pt-4">
                <div className="glass-card rounded-xl p-4 card-hover">
                  <BookOpen className="w-8 h-8 text-primary mb-3" />
                  <h3 className="font-medium text-foreground">Smart Notes</h3>
                  <p className="text-sm text-muted-foreground mt-1">Organize and enhance your study materials</p>
                </div>
                <div className="glass-card rounded-xl p-4 card-hover" style={{ animationDelay: '0.1s' }}>
                  <Layers className="w-8 h-8 text-secondary mb-3" />
                  <h3 className="font-medium text-foreground">AI Flashcards</h3>
                  <p className="text-sm text-muted-foreground mt-1">Auto-generate cards from your notes</p>
                </div>
                <div className="glass-card rounded-xl p-4 card-hover" style={{ animationDelay: '0.2s' }}>
                  <Brain className="w-8 h-8 text-accent mb-3" />
                  <h3 className="font-medium text-foreground">Smart Quizzes</h3>
                  <p className="text-sm text-muted-foreground mt-1">Test yourself with adaptive questions</p>
                </div>
              </div>
            </div>

            {/* Auth Form */}
            <div className="lg:pl-8">
              <AuthForm />
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Dashboard for authenticated users
  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold text-foreground">
          Welcome back! 👋
        </h1>
        <p className="text-muted-foreground mt-2">
          What would you like to study today?
        </p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <Link to="/notes" className="group">
          <div className="glass-card rounded-2xl p-6 card-hover h-full">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
              <BookOpen className="w-7 h-7 text-primary" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">Notes</h3>
            <p className="text-muted-foreground mb-4">
              Create and organize your study notes. Add content to generate flashcards.
            </p>
            <div className="flex items-center text-primary font-medium">
              Open Notes
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </Link>

        <Link to="/flashcards" className="group">
          <div className="glass-card rounded-2xl p-6 card-hover h-full">
            <div className="w-14 h-14 rounded-2xl bg-secondary/10 flex items-center justify-center mb-4 group-hover:bg-secondary/20 transition-colors">
              <Layers className="w-7 h-7 text-secondary" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">Flashcards</h3>
            <p className="text-muted-foreground mb-4">
              Review your AI-generated flashcards and memorize key concepts.
            </p>
            <div className="flex items-center text-secondary font-medium">
              Study Flashcards
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </Link>

        <Link to="/quiz" className="group">
          <div className="glass-card rounded-2xl p-6 card-hover h-full">
            <div className="w-14 h-14 rounded-2xl bg-accent/10 flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
              <Brain className="w-7 h-7 text-accent" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">Quiz Mode</h3>
            <p className="text-muted-foreground mb-4">
              Test your knowledge with AI-generated quizzes from your flashcards.
            </p>
            <div className="flex items-center text-accent font-medium">
              Take a Quiz
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </Link>
      </div>
    </div>
  );
}
