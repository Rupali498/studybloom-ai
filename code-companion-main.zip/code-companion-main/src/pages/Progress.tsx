import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { 
  BarChart3, 
  Loader2, 
  Trophy,
  BookOpen,
  Layers,
  Brain,
  TrendingUp
} from 'lucide-react';

interface QuizSession {
  id: string;
  score: number;
  total_questions: number;
  completed_at: string;
  deck_id: string;
}

interface Stats {
  totalNotes: number;
  totalDecks: number;
  totalQuizzes: number;
  averageScore: number;
}

export default function Progress() {
  const { toast } = useToast();
  const [sessions, setSessions] = useState<QuizSession[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalNotes: 0,
    totalDecks: 0,
    totalQuizzes: 0,
    averageScore: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProgress();
  }, []);

  const fetchProgress = async () => {
    try {
      // Fetch quiz sessions
      const { data: sessionsData, error: sessionsError } = await supabase
        .from('quiz_sessions')
        .select('*')
        .order('completed_at', { ascending: false })
        .limit(10);

      if (sessionsError) throw sessionsError;
      setSessions(sessionsData || []);

      // Fetch counts
      const [notesResult, decksResult] = await Promise.all([
        supabase.from('notes').select('id', { count: 'exact', head: true }),
        supabase.from('flashcard_decks').select('id', { count: 'exact', head: true }),
      ]);

      const totalQuizzes = sessionsData?.length || 0;
      const averageScore = totalQuizzes > 0
        ? Math.round(
            sessionsData!.reduce((acc, s) => acc + (s.score / s.total_questions) * 100, 0) / totalQuizzes
          )
        : 0;

      setStats({
        totalNotes: notesResult.count || 0,
        totalDecks: decksResult.count || 0,
        totalQuizzes,
        averageScore,
      });
    } catch (error) {
      console.error('Error fetching progress:', error);
      toast({ title: 'Error', description: 'Failed to load progress', variant: 'destructive' });
    }

    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Progress</h1>
        <p className="text-muted-foreground">Track your learning journey</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-card rounded-xl p-5">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
            <BookOpen className="w-5 h-5 text-primary" />
          </div>
          <p className="text-3xl font-bold text-foreground">{stats.totalNotes}</p>
          <p className="text-sm text-muted-foreground">Notes Created</p>
        </div>

        <div className="glass-card rounded-xl p-5">
          <div className="w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center mb-3">
            <Layers className="w-5 h-5 text-secondary" />
          </div>
          <p className="text-3xl font-bold text-foreground">{stats.totalDecks}</p>
          <p className="text-sm text-muted-foreground">Flashcard Decks</p>
        </div>

        <div className="glass-card rounded-xl p-5">
          <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center mb-3">
            <Brain className="w-5 h-5 text-accent" />
          </div>
          <p className="text-3xl font-bold text-foreground">{stats.totalQuizzes}</p>
          <p className="text-sm text-muted-foreground">Quizzes Taken</p>
        </div>

        <div className="glass-card rounded-xl p-5">
          <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center mb-3">
            <TrendingUp className="w-5 h-5 text-green-500" />
          </div>
          <p className="text-3xl font-bold text-foreground">{stats.averageScore}%</p>
          <p className="text-sm text-muted-foreground">Average Score</p>
        </div>
      </div>

      {/* Recent Quizzes */}
      <div className="glass-card rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Trophy className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">Recent Quizzes</h2>
            <p className="text-sm text-muted-foreground">Your latest quiz results</p>
          </div>
        </div>

        {sessions.length === 0 ? (
          <div className="text-center py-8">
            <BarChart3 className="w-12 h-12 text-muted-foreground/50 mx-auto mb-3" />
            <p className="text-muted-foreground">No quizzes taken yet</p>
          </div>
        ) : (
          <div className="space-y-3">
            {sessions.map((session) => {
              const percentage = Math.round((session.score / session.total_questions) * 100);
              const date = new Date(session.completed_at).toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              });

              return (
                <div
                  key={session.id}
                  className="flex items-center justify-between p-4 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg ${
                      percentage >= 80 ? 'bg-green-500/10 text-green-500' :
                      percentage >= 60 ? 'bg-secondary/10 text-secondary' :
                      'bg-destructive/10 text-destructive'
                    }`}>
                      {percentage}%
                    </div>
                    <div>
                      <p className="font-medium text-foreground">
                        {session.score} / {session.total_questions} correct
                      </p>
                      <p className="text-sm text-muted-foreground">{date}</p>
                    </div>
                  </div>

                  <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all ${
                        percentage >= 80 ? 'bg-green-500' :
                        percentage >= 60 ? 'bg-secondary' :
                        'bg-destructive'
                      }`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
