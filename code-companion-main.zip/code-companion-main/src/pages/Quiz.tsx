import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { 
  Brain, 
  Loader2, 
  CheckCircle2, 
  XCircle, 
  Trophy,
  RotateCcw,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

interface Deck {
  id: string;
  title: string;
  flashcards?: { front: string; back: string }[];
}

export default function Quiz() {
  const [searchParams] = useSearchParams();
  const deckId = searchParams.get('deck');
  const { user } = useAuth();
  const { toast } = useToast();

  const [decks, setDecks] = useState<Deck[]>([]);
  const [selectedDeck, setSelectedDeck] = useState<Deck | null>(null);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [quizComplete, setQuizComplete] = useState(false);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    fetchDecks();
  }, []);

  useEffect(() => {
    if (deckId && decks.length > 0) {
      const deck = decks.find(d => d.id === deckId);
      if (deck) {
        startQuiz(deck);
      }
    }
  }, [deckId, decks]);

  const fetchDecks = async () => {
    const { data, error } = await supabase
      .from('flashcard_decks')
      .select(`*, flashcards (front, back)`)
      .order('created_at', { ascending: false });

    if (error) {
      toast({ title: 'Error', description: 'Failed to load decks', variant: 'destructive' });
    } else {
      setDecks(data || []);
    }
    setLoading(false);
  };

  const startQuiz = async (deck: Deck) => {
    if (!deck.flashcards || deck.flashcards.length < 2) {
      toast({ 
        title: 'Not enough cards', 
        description: 'Need at least 2 flashcards to generate a quiz', 
        variant: 'destructive' 
      });
      return;
    }

    setSelectedDeck(deck);
    setGenerating(true);

    try {
      const { data, error } = await supabase.functions.invoke('generate-quiz', {
        body: { flashcards: deck.flashcards },
      });

      if (error) throw error;

      if (data?.questions && data.questions.length > 0) {
        setQuestions(data.questions);
        setCurrentQuestion(0);
        setScore(0);
        setQuizComplete(false);
      } else {
        throw new Error('No questions generated');
      }
    } catch (error) {
      console.error('Error generating quiz:', error);
      toast({
        title: 'Error',
        description: 'Failed to generate quiz. Please try again.',
        variant: 'destructive',
      });
      setSelectedDeck(null);
    }

    setGenerating(false);
  };

  const handleAnswer = (index: number) => {
    if (showResult) return;

    setSelectedAnswer(index);
    setShowResult(true);

    if (index === questions[currentQuestion].correctIndex) {
      setScore(score + 1);
    }
  };

  const nextQuestion = async () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      // Quiz complete - save session
      setQuizComplete(true);
      
      if (user && selectedDeck) {
        await supabase.from('quiz_sessions').insert({
          user_id: user.id,
          deck_id: selectedDeck.id,
          score: score + (selectedAnswer === questions[currentQuestion].correctIndex ? 1 : 0),
          total_questions: questions.length,
        });
      }
    }
  };

  const restartQuiz = () => {
    if (selectedDeck) {
      startQuiz(selectedDeck);
    }
  };

  const exitQuiz = () => {
    setSelectedDeck(null);
    setQuestions([]);
    setQuizComplete(false);
    setCurrentQuestion(0);
    setScore(0);
    setSelectedAnswer(null);
    setShowResult(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  // Quiz complete view
  if (quizComplete && selectedDeck) {
    const finalScore = score + (selectedAnswer === questions[currentQuestion]?.correctIndex ? 1 : 0);
    const percentage = Math.round((finalScore / questions.length) * 100);

    return (
      <div className="max-w-lg mx-auto text-center space-y-8 animate-fade-in">
        <div className="w-24 h-24 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
          <Trophy className="w-12 h-12 text-primary" />
        </div>

        <div>
          <h2 className="text-3xl font-bold text-foreground mb-2">Quiz Complete!</h2>
          <p className="text-muted-foreground">{selectedDeck.title}</p>
        </div>

        <div className="glass-card rounded-2xl p-8">
          <div className="text-6xl font-bold gradient-text mb-2">{percentage}%</div>
          <p className="text-muted-foreground">
            You got {finalScore} out of {questions.length} questions correct
          </p>
        </div>

        <div className="flex gap-4 justify-center">
          <Button variant="outline" onClick={exitQuiz}>
            Back to Decks
          </Button>
          <Button onClick={restartQuiz} className="gap-2">
            <RotateCcw className="w-4 h-4" />
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  // Quiz in progress
  if (selectedDeck && questions.length > 0) {
    const question = questions[currentQuestion];

    return (
      <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
        {generating ? (
          <div className="flex flex-col items-center justify-center h-64 gap-4">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
            <p className="text-muted-foreground">Generating quiz questions...</p>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <Button variant="ghost" onClick={exitQuiz}>Exit Quiz</Button>
              <span className="text-sm text-muted-foreground">
                Question {currentQuestion + 1} of {questions.length}
              </span>
            </div>

            {/* Progress bar */}
            <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary transition-all duration-300"
                style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
              />
            </div>

            {/* Question */}
            <div className="glass-card rounded-2xl p-8">
              <h3 className="text-xl font-medium text-foreground mb-6">
                {question.question}
              </h3>

              <div className="space-y-3">
                {question.options.map((option, index) => {
                  let buttonClass = 'w-full text-left p-4 rounded-xl border-2 transition-all ';
                  
                  if (showResult) {
                    if (index === question.correctIndex) {
                      buttonClass += 'border-green-500 bg-green-500/10 text-foreground';
                    } else if (index === selectedAnswer) {
                      buttonClass += 'border-destructive bg-destructive/10 text-foreground';
                    } else {
                      buttonClass += 'border-border text-muted-foreground';
                    }
                  } else {
                    buttonClass += 'border-border hover:border-primary hover:bg-primary/5 text-foreground';
                  }

                  return (
                    <button
                      key={index}
                      className={buttonClass}
                      onClick={() => handleAnswer(index)}
                      disabled={showResult}
                    >
                      <span className="flex items-center gap-3">
                        <span className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm font-medium">
                          {String.fromCharCode(65 + index)}
                        </span>
                        {option}
                        {showResult && index === question.correctIndex && (
                          <CheckCircle2 className="w-5 h-5 text-green-500 ml-auto" />
                        )}
                        {showResult && index === selectedAnswer && index !== question.correctIndex && (
                          <XCircle className="w-5 h-5 text-destructive ml-auto" />
                        )}
                      </span>
                    </button>
                  );
                })}
              </div>

              {showResult && (
                <div className="mt-6 p-4 rounded-xl bg-muted/50 animate-fade-in">
                  <p className="text-sm text-muted-foreground">
                    <span className="font-medium text-foreground">Explanation:</span> {question.explanation}
                  </p>
                </div>
              )}
            </div>

            {showResult && (
              <div className="flex justify-end">
                <Button onClick={nextQuestion} className="gap-2">
                  {currentQuestion < questions.length - 1 ? 'Next Question' : 'See Results'}
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    );
  }

  // Deck selection view
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Quiz Mode</h1>
        <p className="text-muted-foreground">Test your knowledge with AI-generated quizzes</p>
      </div>

      {decks.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center">
          <Brain className="w-16 h-16 text-muted-foreground/50 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No flashcard decks available</h3>
          <p className="text-muted-foreground mb-6">
            Create notes and generate flashcards first to take quizzes
          </p>
          <Link to="/notes">
            <Button>Go to Notes</Button>
          </Link>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {decks.map((deck) => (
            <div key={deck.id} className="glass-card rounded-xl p-5 card-hover">
              <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center mb-3">
                <Brain className="w-5 h-5 text-accent" />
              </div>

              <h3 className="font-semibold text-foreground mb-1 line-clamp-1">
                {deck.title}
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                {deck.flashcards?.length || 0} cards
              </p>

              <Button
                variant="outline"
                size="sm"
                className="w-full gap-2"
                onClick={() => startQuiz(deck)}
                disabled={!deck.flashcards || deck.flashcards.length < 2 || generating}
              >
                {generating && selectedDeck?.id === deck.id ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Brain className="w-4 h-4" />
                )}
                Start Quiz
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
