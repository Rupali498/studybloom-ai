import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  Plus, 
  BookOpen, 
  Sparkles, 
  Trash2, 
  Edit3,
  Loader2,
  FileText
} from 'lucide-react';

interface Note {
  id: string;
  title: string;
  content: string;
  subject: string | null;
  created_at: string;
  updated_at: string;
}

export default function Notes() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [generating, setGenerating] = useState<string | null>(null);

  // Form state
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [subject, setSubject] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchNotes();
  }, []);

  const fetchNotes = async () => {
    const { data, error } = await supabase
      .from('notes')
      .select('*')
      .order('updated_at', { ascending: false });

    if (error) {
      toast({ title: 'Error', description: 'Failed to load notes', variant: 'destructive' });
    } else {
      setNotes(data || []);
    }
    setLoading(false);
  };

  const handleSaveNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setSaving(true);

    if (editingNote) {
      const { error } = await supabase
        .from('notes')
        .update({ title, content, subject: subject || null })
        .eq('id', editingNote.id);

      if (error) {
        toast({ title: 'Error', description: 'Failed to update note', variant: 'destructive' });
      } else {
        toast({ title: 'Success', description: 'Note updated!' });
        fetchNotes();
        resetForm();
      }
    } else {
      const { error } = await supabase
        .from('notes')
        .insert({ title, content, subject: subject || null, user_id: user.id });

      if (error) {
        toast({ title: 'Error', description: 'Failed to create note', variant: 'destructive' });
      } else {
        toast({ title: 'Success', description: 'Note created!' });
        fetchNotes();
        resetForm();
      }
    }

    setSaving(false);
  };

  const handleDeleteNote = async (id: string) => {
    const { error } = await supabase.from('notes').delete().eq('id', id);

    if (error) {
      toast({ title: 'Error', description: 'Failed to delete note', variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: 'Note deleted' });
      fetchNotes();
    }
  };

  const handleGenerateFlashcards = async (note: Note) => {
    if (!user) return;
    setGenerating(note.id);

    try {
      const { data, error } = await supabase.functions.invoke('generate-flashcards', {
        body: { content: note.content, count: 5 },
      });

      if (error) throw error;

      if (data?.flashcards && data.flashcards.length > 0) {
        // Create a new deck
        const { data: deck, error: deckError } = await supabase
          .from('flashcard_decks')
          .insert({
            title: `${note.title} - Flashcards`,
            description: `Generated from note: ${note.title}`,
            user_id: user.id,
            note_id: note.id,
          })
          .select()
          .single();

        if (deckError) throw deckError;

        // Insert flashcards
        const flashcardsToInsert = data.flashcards.map((fc: { front: string; back: string }) => ({
          deck_id: deck.id,
          front: fc.front,
          back: fc.back,
        }));

        const { error: cardsError } = await supabase
          .from('flashcards')
          .insert(flashcardsToInsert);

        if (cardsError) throw cardsError;

        toast({
          title: 'Flashcards Generated!',
          description: `Created ${data.flashcards.length} flashcards from your note.`,
        });
      }
    } catch (error) {
      console.error('Error generating flashcards:', error);
      toast({
        title: 'Error',
        description: 'Failed to generate flashcards. Please try again.',
        variant: 'destructive',
      });
    }

    setGenerating(null);
  };

  const resetForm = () => {
    setTitle('');
    setContent('');
    setSubject('');
    setEditingNote(null);
    setDialogOpen(false);
  };

  const openEditDialog = (note: Note) => {
    setEditingNote(note);
    setTitle(note.title);
    setContent(note.content);
    setSubject(note.subject || '');
    setDialogOpen(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Notes</h1>
          <p className="text-muted-foreground">Create notes and generate flashcards with AI</p>
        </div>

        <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              New Note
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingNote ? 'Edit Note' : 'Create New Note'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSaveNote} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Note title"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="subject">Subject (optional)</Label>
                  <Input
                    id="subject"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="e.g., Biology, History"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="content">Content</Label>
                <Textarea
                  id="content"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Write your study notes here... The more detailed, the better the flashcards!"
                  required
                  className="min-h-[300px]"
                />
              </div>
              <div className="flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
                <Button type="submit" disabled={saving}>
                  {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  {editingNote ? 'Update Note' : 'Create Note'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {notes.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 text-center">
          <FileText className="w-16 h-16 text-muted-foreground/50 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No notes yet</h3>
          <p className="text-muted-foreground mb-6">
            Create your first note to get started with AI-powered study tools
          </p>
          <Button onClick={() => setDialogOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Create Your First Note
          </Button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {notes.map((note) => (
            <div
              key={note.id}
              className="glass-card rounded-xl p-5 card-hover group"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-primary" />
                </div>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => openEditDialog(note)}
                  >
                    <Edit3 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive"
                    onClick={() => handleDeleteNote(note.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <h3 className="font-semibold text-foreground mb-1 line-clamp-1">
                {note.title}
              </h3>
              {note.subject && (
                <span className="inline-block text-xs px-2 py-1 rounded-full bg-secondary/10 text-secondary mb-2">
                  {note.subject}
                </span>
              )}
              <p className="text-sm text-muted-foreground line-clamp-3 mb-4">
                {note.content}
              </p>

              <Button
                variant="outline"
                size="sm"
                className="w-full gap-2"
                onClick={() => handleGenerateFlashcards(note)}
                disabled={generating === note.id}
              >
                {generating === note.id ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Sparkles className="w-4 h-4" />
                )}
                Generate Flashcards
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
